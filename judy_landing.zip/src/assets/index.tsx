export { default as Shirts1 } from "./shirts1.jpg";
export { default as Shirts2 } from "./shirts2.jpg";
export { default as Shirts3 } from "./shirts3.jpg";
export { default as Shirts4 } from "./shirts4.jpg";
export { default as Shirts5 } from "./shirts5.jpg";
export { default as Shoes1 } from "./shoes1.jpg";
export { default as Shoes2 } from "./shoes2.jpg";

export { default as FacebookIcon } from "./facebook1.svg";
export { default as InstagramIcon } from "./instagram1.svg";
export { default as YoutubeIcon } from "./youtube1.svg";
export { default as TwitterIcon } from "./twitter1.svg";
export { default as LinkedInIcon } from "./linkedin1.svg";

export { default as SearchIcon } from "./search.svg";
export { default as NairaSign } from "./NairaSign.svg";
export { default as userIcon } from "./UserIcon.png";
export { default as X_Icon } from "./X_Icon.svg";
export { default as logoIcon } from "./judyhub-logo02.png";
export { default as logoSvg } from "./judyhub-logo.svg";

