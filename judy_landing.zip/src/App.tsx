/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from 'react';
import { MainContext } from "./context/mainContext";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import Home from './pages/Home';
import MuiNavbar from "./components/MuiNavbar";
import { AllProducts } from './data';


function App() {
  const [active, setActive] = useState(false);
  const [menuOpened, setMenuOpened] = useState(false);
  const [fetchedData, setFetchedData] = useState([]);
  const primaryGreen = "#0db915";
  const secondaryBrown = "#613207";

  const simulateFetchProductData = () => {
    console.log("Fetching...");
    setTimeout(() => {
      setFetchedData({ ...fetchedData, AllProducts });
    }, 1000);
  }
  
  useEffect(() => {
    setTimeout(() => {
      simulateFetchProductData();
    }, 3000);
  }, [])

  return (
    <>
      <MainContext.Provider 
        value={{ 
          active, setActive, fetchedData, setFetchedData, menuOpened, 
          setMenuOpened, primaryGreen, secondaryBrown, 
        }}
      >
        <ToastContainer 
          position='top-right' 
          autoClose={1000} 
          hideProgressBar={false} 
          newestOnTop={true} 
          closeOnClick
          draggable
          pauseOnHover
          theme='light'
        />
          <BrowserRouter>
            <MuiNavbar/>
            <Routes>
              <Route path={"/"} element={<Home/>} />
            </Routes>          
          </BrowserRouter>


      </MainContext.Provider>
    </>
  )
}

export default App
