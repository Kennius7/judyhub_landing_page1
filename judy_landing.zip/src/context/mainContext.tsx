import { createContext, SetStateAction } from "react";

type MainContextType = {
    active: boolean;
    setActive: (active: boolean) => void;
    fetchedData: { id: number; name: string; category: string; tags: string; image: string; newPrice: string; oldPrice: string; description: string; }[];
    setFetchedData: React.Dispatch<SetStateAction<{ id: number; name: string; category: string; tags: string; image: string; newPrice: string; oldPrice: string; description: string; }[]>>
    menuOpened: boolean;
    setMenuOpened: (menuOpened: boolean) => void;
    primaryGreen: string;
    secondaryBrown: string;
};

export const MainContext = createContext<MainContextType>({
    active: false,
    setActive: () => {},
    fetchedData: [],
    setFetchedData: () => {},
    menuOpened: false,
    setMenuOpened: () => {},
    primaryGreen: "#0db915",
    secondaryBrown: "#613207",
});

